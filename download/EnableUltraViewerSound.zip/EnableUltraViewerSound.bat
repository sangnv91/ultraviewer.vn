@echo off
REG DELETE "HKEY_CURRENT_USER\\Software\\UltraViewer\\DisableNotifyConnectSound" /f
echo Notify sound is now enabled.
pause