@echo off
REG ADD "HKEY_CURRENT_USER\\Software\\UltraViewer\\DisableNotifyConnectSound" /v "" /t REG_DWORD /d 1 /f
echo Notify sound is now disabled.
pause